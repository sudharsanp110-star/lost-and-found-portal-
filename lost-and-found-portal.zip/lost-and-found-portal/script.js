"use strict";
/* ---------- helpers & constants ---------- */
const $ = id => document.getElementById(id);
const KEY = "lfp_items";
const CATS = ["Bags","Keys","Documents","Electronics","Books","Clothing","Accessories","Others"];
const ICON = {Bags:"\uD83C\uDF92",Keys:"\uD83D\uDD11",Documents:"\uD83D\uDCC4",Electronics:"\uD83D\uDCF1",Books:"\uD83D\uDCDA",Clothing:"\uD83D\uDC55",Accessories:"\uD83D\uDC53",Others:"\uD83D\uDCE6"};
const PHONE_RE = /^[6-9]\d{9}$/;
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const today = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };

let items = [];
let showResolved = false;
let imageData = "";
let viewId = null;

/* ---------- local storage ---------- */
function seed() {
  const t = today();
  return [
    {id:1,type:"Lost",name:"Black laptop bag",category:"Bags",desc:"Black backpack with a blue keychain and a laptop inside.",location:"Library, 2nd floor",date:t,contactName:"Ravi Kumar",phone:"9876500011",image:"",resolved:false,requests:[]},
    {id:2,type:"Found",name:"Bunch of keys",category:"Keys",desc:"Three keys with a red tag marked 'H-12'.",location:"Canteen entrance",date:t,contactName:"Meena S",phone:"9876500022",image:"",resolved:false,requests:[]},
    {id:3,type:"Found",name:"College ID card",category:"Documents",desc:"Student ID card found near the gate, name partly faded.",location:"Main gate",date:t,contactName:"Security Office",phone:"9876500033",image:"",resolved:false,requests:[]},
    {id:4,type:"Lost",name:"Wireless earbuds",category:"Electronics",desc:"White earbuds in a small charging case with a sticker.",location:"Seminar hall",date:t,contactName:"Divya R",phone:"9876500044",image:"",resolved:true,requests:[]}
  ];
}
function load() {
  try {
    const raw = localStorage.getItem(KEY);
    const data = raw ? JSON.parse(raw) : null;
    if (Array.isArray(data)) return data;
  } catch (e) { /* fall through to sample data */ }
  const s = seed();
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {}
  return s;
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(items)); return true; }
  catch (e) { toast("Storage is full. Delete some items or use smaller photos."); return false; }
}

/* ---------- toast ---------- */
function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.remove("show"), 2200);
}

/* ---------- render list ---------- */
function render() {
  const q = $("search").value.trim().toLowerCase();
  const c = $("fCat").value;
  const t = $("fType").value;

  $("tabActive").textContent = `Active (${items.filter(i => !i.resolved).length})`;
  $("tabResolved").textContent = `Resolved (${items.filter(i => i.resolved).length})`;
  $("tabActive").classList.toggle("on", !showResolved);
  $("tabResolved").classList.toggle("on", showResolved);

  const rows = items
    .filter(i => !!i.resolved === showResolved)
    .filter(i => !c || i.category === c)
    .filter(i => !t || i.type === t)
    .filter(i => !q || [i.name, i.location, i.desc].some(s => String(s || "").toLowerCase().includes(q)))
    .sort((a, b) => String(b.date).localeCompare(String(a.date)) || b.id - a.id);

  $("list").innerHTML = rows.length
    ? rows.map(i => `<article class="card">
  <div class="thumb">${i.image ? `<img src="${esc(i.image)}" alt="${esc(i.name)}">` : (ICON[i.category] || "\uD83D\uDCE6")}<span class="badge ${esc(i.type)}">${esc(i.type)}</span></div>
  <div class="body"><h3>${esc(i.name)}</h3><div class="muted">${esc(i.category)} &middot; ${esc(i.location)}</div><div class="muted">${esc(i.date)}</div>
  <button class="btn alt" data-view="${i.id}">View details</button></div></article>`).join("")
    : `<div class="empty">${showResolved ? "No resolved items yet." : "No items match your search. Clear the filters or report a new item."}</div>`;
}

/* event delegation: one listener opens any card */
$("list").addEventListener("click", e => {
  const b = e.target.closest("[data-view]");
  if (b) openView(Number(b.dataset.view));
});
["search", "fCat", "fType"].forEach(id => {
  $(id).addEventListener("input", render);
  $(id).addEventListener("change", render);
});
$("tabActive").onclick = () => { showResolved = false; render(); };
$("tabResolved").onclick = () => { showResolved = true; render(); };

/* ---------- dialogs ---------- */
document.querySelectorAll("[data-close]").forEach(b => b.onclick = () => b.closest("dialog").close());
document.querySelectorAll("dialog").forEach(d => d.addEventListener("click", e => { if (e.target === d) d.close(); }));
$("viewDlg").addEventListener("close", () => { viewId = null; });

$("openForm").onclick = () => {
  $("form").reset();
  imageData = "";
  $("preview").style.display = "none";
  document.querySelectorAll(".err").forEach(e => e.textContent = "");
  $("date").value = today();
  $("formDlg").showModal();
};

/* ---------- image upload + preview ---------- */
function resizeImage(dataUrl, cb) {
  const im = new Image();
  im.onload = () => {
    const scale = Math.min(1, 480 / Math.max(im.width, im.height));
    const cv = document.createElement("canvas");
    cv.width = Math.max(1, Math.round(im.width * scale));
    cv.height = Math.max(1, Math.round(im.height * scale));
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, cv.width, cv.height);
    ctx.drawImage(im, 0, 0, cv.width, cv.height);
    cb(cv.toDataURL("image/jpeg", 0.75));
  };
  im.onerror = () => cb("");
  im.src = dataUrl;
}
$("img").onchange = e => {
  const f = e.target.files[0];
  $("eImg").textContent = "";
  imageData = "";
  $("preview").style.display = "none";
  if (!f) return;
  if (!f.type.startsWith("image/")) { $("eImg").textContent = "Choose an image file (JPG, PNG or WEBP)."; e.target.value = ""; return; }
  if (f.size > 5 * 1024 * 1024) { $("eImg").textContent = "Image is larger than 5 MB. Choose a smaller one."; e.target.value = ""; return; }
  const fr = new FileReader();
  fr.onload = () => resizeImage(fr.result, out => {
    if (!out) { $("eImg").textContent = "Could not read this image. Try another file."; e.target.value = ""; return; }
    imageData = out;
    $("preview").src = out;
    $("preview").style.display = "block";
  });
  fr.onerror = () => { $("eImg").textContent = "Could not read this file."; e.target.value = ""; };
  fr.readAsDataURL(f);
};
$("phone").addEventListener("input", e => { e.target.value = e.target.value.replace(/\D/g, ""); });

/* ---------- report form: validation + save ---------- */
$("form").onsubmit = e => {
  e.preventDefault();
  const v = {
    type: document.querySelector('input[name="type"]:checked').value,
    name: $("name").value.trim(),
    cat: $("cat").value,
    date: $("date").value,
    loc: $("loc").value.trim(),
    desc: $("desc").value.trim(),
    cname: $("cname").value.trim(),
    phone: $("phone").value.trim()
  };
  const errs = {
    eName:  v.name.length >= 3 ? "" : "Enter the item name (at least 3 characters).",
    eCat:   v.cat ? "" : "Choose a category.",
    eDate:  !v.date ? "Choose the date." : (v.date > today() ? "The date cannot be in the future." : ""),
    eLoc:   v.loc ? "" : "Enter the place.",
    eDesc:  v.desc.length >= 10 ? "" : "Describe the item in at least 10 characters.",
    eCname: v.cname ? "" : "Enter your name.",
    ePhone: PHONE_RE.test(v.phone) ? "" : "Enter a 10-digit number starting with 6, 7, 8 or 9."
  };
  Object.keys(errs).forEach(k => $(k).textContent = errs[k]);
  const bad = Object.keys(errs).find(k => errs[k]);
  if (bad) {
    const field = {eName:"name",eCat:"cat",eDate:"date",eLoc:"loc",eDesc:"desc",eCname:"cname",ePhone:"phone"}[bad];
    $(field).focus();
    return;
  }
  const item = {
    id: Date.now(),
    type: v.type,
    name: v.name,
    category: v.cat,
    desc: v.desc,
    location: v.loc,
    date: v.date,
    contactName: v.cname,
    phone: v.phone,
    image: imageData,
    resolved: false,
    requests: []
  };
  items.unshift(item);
  if (!save()) { items.shift(); return; }
  $("formDlg").close();
  $("search").value = ""; $("fCat").value = ""; $("fType").value = "";
  showResolved = false;
  render();
  toast("Item saved");
};

/* ---------- details dialog ---------- */
function openView(id) {
  const i = items.find(x => x.id === id);
  if (!i) return;
  viewId = id;
  const reqs = i.requests || [];
  $("vTitle").textContent = i.name;
  $("vBody").innerHTML = `
    ${i.image ? `<img class="big" src="${esc(i.image)}" alt="${esc(i.name)}">` : `<div class="big ph">${ICON[i.category] || "\uD83D\uDCE6"}</div>`}
    <dl class="info">
      <dt>Status</dt><dd class="st ${esc(i.type)}">${esc(i.type)}${i.resolved ? " (Resolved)" : ""}</dd>
      <dt>Category</dt><dd>${esc(i.category)}</dd>
      <dt>Place</dt><dd>${esc(i.location)}</dd>
      <dt>Date</dt><dd>${esc(i.date)}</dd>
      <dt>Description</dt><dd>${esc(i.desc)}</dd>
      <dt>Contact</dt><dd>${esc(i.contactName)}, ${esc(i.phone)}</dd>
    </dl>
    ${i.resolved ? "" : `
    <h3>${i.type === "Lost" ? "Seen this item? Tell the owner" : "Is this yours? Contact the finder"}</h3>
    <form id="reqForm" novalidate>
      <div class="two">
        <div><input id="rName" placeholder="Your name" maxlength="50" aria-label="Your name"><div class="err" id="erName"></div></div>
        <div><input id="rPhone" placeholder="Your phone" inputmode="numeric" maxlength="10" aria-label="Your phone"><div class="err" id="erPhone"></div></div>
      </div>
      <div style="margin-top:10px"><textarea id="rMsg" rows="2" maxlength="200" placeholder="Message (for example, proof of ownership or where you saw it)" aria-label="Message"></textarea><div class="err" id="erMsg"></div></div>
      <button class="btn" type="submit">Send request</button>
    </form>`}
    <h3>Requests (${reqs.length})</h3>
    ${reqs.length ? reqs.map(r => `<div class="req"><b>${esc(r.name)}</b> (${esc(r.phone)})<br>${esc(r.message)}</div>`).join("") : `<div class="muted">No requests yet.</div>`}
    <div class="acts">
      ${i.resolved
        ? `<button class="btn alt" id="reopenBtn" type="button">Move back to active</button>`
        : `<button class="btn green" id="resolveBtn" type="button">Mark as resolved</button>`}
      <button class="btn red" id="deleteBtn" type="button">Delete item</button>
    </div>`;

  const rf = $("reqForm");
  if (rf) {
    $("rPhone").addEventListener("input", e => { e.target.value = e.target.value.replace(/\D/g, ""); });
    rf.onsubmit = ev => { ev.preventDefault(); sendRequest(i); };
  }
  if ($("resolveBtn")) $("resolveBtn").onclick = () => setResolved(i, true);
  if ($("reopenBtn")) $("reopenBtn").onclick = () => setResolved(i, false);
  $("deleteBtn").onclick = () => removeItem(i);

  if (!$("viewDlg").open) $("viewDlg").showModal();
}

function sendRequest(i) {
  const name = $("rName").value.trim();
  const phone = $("rPhone").value.trim();
  const message = $("rMsg").value.trim();
  $("erName").textContent = name ? "" : "Enter your name.";
  $("erPhone").textContent = PHONE_RE.test(phone) ? "" : "Enter a 10-digit number starting with 6, 7, 8 or 9.";
  $("erMsg").textContent = message.length >= 5 ? "" : "Write a message (at least 5 characters).";
  if (!name || !PHONE_RE.test(phone) || message.length < 5) return;
  i.requests = i.requests || [];
  i.requests.push({name, phone, message, time: new Date().toLocaleString()});
  if (!save()) { i.requests.pop(); return; }
  openView(i.id);
  render();
  toast("Request sent");
}

function setResolved(i, flag) {
  i.resolved = flag;
  if (!save()) { i.resolved = !flag; return; }
  $("viewDlg").close();
  showResolved = flag;
  render();
  toast(flag ? "Marked as resolved" : "Moved back to active");
}

function removeItem(i) {
  if (!confirm("Delete this item permanently?")) return;
  const idx = items.indexOf(i);
  items.splice(idx, 1);
  if (!save()) { items.splice(idx, 0, i); return; }
  $("viewDlg").close();
  render();
  toast("Item deleted");
}

/* ---------- start ---------- */
(function init() {
  $("fCat").innerHTML = `<option value="">All categories</option>` + CATS.map(c => `<option>${c}</option>`).join("");
  $("cat").innerHTML = `<option value="">Select category</option>` + CATS.map(c => `<option>${c}</option>`).join("");
  $("date").max = today();
  items = load();
  render();
})();
